var loginTab = 0;

function init()
{
		chrome.tabs.create({url:"https://securelogin.wlan.cuhk.edu.hk/upload/custom/CU_Portal/login.html"},function(tab){
			loginTab = tab.id;
		});

}

chrome.browserAction.onClicked.addListener(function(tab){

	init();
	
});
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse){
	chrome.notifications.create("",{type:"basic",iconUrl:"cuhk.png",title:"CUHK WiFI Login Helper",message:request.msg},function(id){

	});
});
