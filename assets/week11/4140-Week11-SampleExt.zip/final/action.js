function fill()
{

	$( document ).ready(function() {

		var url = window.location.href;

		if(url.search("errmsg") == -1)
		{
		 	$("#user").val("s12345678");
			$("#password").val("12345678");
			$("form").submit();
		}
		else
		{
			if($("#errorbox").length)
			{
				var errText = $("#errorbox").text();
				chrome.runtime.sendMessage({msg: errText}, function(response) {
				  
				});
			}
				//alert($("#errorbox").text());
		}
	});
	

	//
	//document.getElementById("user").value="aaa";
	console.log("Filled");

}
fill();